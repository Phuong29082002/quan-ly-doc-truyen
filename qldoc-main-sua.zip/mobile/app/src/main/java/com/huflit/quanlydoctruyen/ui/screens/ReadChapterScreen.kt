package com.huflit.quanlydoctruyen.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.huflit.quanlydoctruyen.data.ApiClient
import com.huflit.quanlydoctruyen.data.ChapterContent
import com.huflit.quanlydoctruyen.data.LockInfo
import com.huflit.quanlydoctruyen.data.SessionManager
import com.huflit.quanlydoctruyen.data.UiState
import com.huflit.quanlydoctruyen.data.formatVnd
import com.huflit.quanlydoctruyen.data.load
import com.huflit.quanlydoctruyen.ui.components.ChapterBody
import com.huflit.quanlydoctruyen.ui.components.ErrorBox
import com.huflit.quanlydoctruyen.ui.components.LoadingBox

// PB14: đọc chương, chuyển chương, chỉnh cỡ chữ, chế độ tối
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReadChapterScreen(storyId: Int, number: Int, onGoTo: (Int) -> Unit, onLogin: () -> Unit, onBack: () -> Unit) {
    var retry by remember { mutableIntStateOf(0) }
    val state by produceState<UiState<ChapterContent>>(UiState.Loading, storyId, number, retry, SessionManager.user?.id) {
        value = UiState.Loading
        value = load { ApiClient.api.readChapter(storyId, number) }
    }

    var fontSize by remember { mutableIntStateOf(SessionManager.readerFontSize) }
    var dark by remember { mutableStateOf(SessionManager.readerDarkMode) }

    val background = if (dark) Color(0xFF1C1C1E) else MaterialTheme.colorScheme.background
    val textColor = if (dark) Color(0xFFE5E5E5) else MaterialTheme.colorScheme.onBackground

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text((state as? UiState.Success)?.data?.storyTitle ?: "Đọc truyện", maxLines = 1, overflow = TextOverflow.Ellipsis)
                },
                navigationIcon = { TextButton(onClick = onBack) { Text("‹ Mục lục") } }
            )
        }
    ) { padding ->
        Surface(Modifier.padding(padding).fillMaxSize(), color = background, contentColor = textColor) {
            when (val s = state) {
                is UiState.Loading -> LoadingBox()
                is UiState.Error ->
                    // PB22: chương trả phí chưa có quyền đọc
                    if (s.lock != null) LockedChapter(number, s.lock, onLogin, onBack)
                    else ErrorBox(s.message, onRetry = if (s.code == 403) null else ({ retry++ }))
                is UiState.Success -> {
                    val c = s.data
                    Column(Modifier.verticalScroll(rememberScrollState(), true).padding(16.dp)) {
                        Text(
                            "Chương ${c.number}: ${c.title}",
                            fontWeight = FontWeight.Bold,
                            fontSize = 20.sp,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth()
                        )

                        Row(
                            Modifier.fillMaxWidth().padding(vertical = 8.dp),
                            horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            TextButton(onClick = { fontSize = (fontSize - 2).coerceAtLeast(14); SessionManager.readerFontSize = fontSize }) { Text("A-") }
                            Text("$fontSize")
                            TextButton(onClick = { fontSize = (fontSize + 2).coerceAtMost(30); SessionManager.readerFontSize = fontSize }) { Text("A+") }
                            TextButton(onClick = { dark = !dark; SessionManager.readerDarkMode = dark }) {
                                Text(if (dark) "Nền sáng" else "Nền tối")
                            }
                        }

                        ChapterNav(c, onGoTo)

                        // PB43: chữ xen kẽ ảnh minh họa
                        ChapterBody(c.content, fontSize)

                        ChapterNav(c, onGoTo)
                    }
                }
            }
        }
    }
}

@Composable
private fun ChapterNav(c: ChapterContent, onGoTo: (Int) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        OutlinedButton(
            onClick = { c.prevNumber?.let(onGoTo) },
            enabled = c.prevNumber != null,
            modifier = Modifier.weight(1f)
        ) { Text("‹ Chương trước") }
        Button(
            onClick = { c.nextNumber?.let(onGoTo) },
            enabled = c.nextNumber != null,
            modifier = Modifier.weight(1f)
        ) { Text("Chương sau ›") }
    }
}

@Composable
private fun LockedChapter(number: Int, lock: LockInfo, onLogin: () -> Unit, onBack: () -> Unit) {
    val loggedIn = SessionManager.user != null
    Column(
        Modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("Chương $number là nội dung trả phí", fontWeight = FontWeight.Bold, fontSize = 20.sp, textAlign = TextAlign.Center)
        if (!lock.storyTitle.isNullOrBlank()) {
            Text(lock.storyTitle, modifier = Modifier.padding(top = 4.dp))
        }
        Spacer(Modifier.height(16.dp))

        if (!loggedIn) {
            Text("Vui lòng đăng nhập để đọc chương này.", textAlign = TextAlign.Center)
            Button(onClick = onLogin, modifier = Modifier.padding(top = 12.dp)) { Text("Đăng nhập") }
        } else {
            Text("Bạn cần có gói đọc còn hạn hoặc mua truyện để đọc chương này.", textAlign = TextAlign.Center)
            if (lock.price != null && lock.price > 0) {
                Text("Giá mua truyện: ${formatVnd(lock.price)}", fontWeight = FontWeight.Medium, modifier = Modifier.padding(top = 8.dp))
            }
            Text(
                "Chức năng đăng ký gói và mua truyện sẽ được bổ sung ở bản cập nhật tiếp theo.",
                fontSize = 12.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(top = 8.dp)
            )
        }
        TextButton(onClick = onBack, modifier = Modifier.padding(top = 12.dp)) { Text("Về mục lục") }
    }
}
